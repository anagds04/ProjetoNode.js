const express = require("express"); // carregando o express e adicionando ele dentro da const express
const app = express(); // criando o objeto da classe express
app.get("/", (req, res) => { // get ( método para criar uma rota ) que retorna uma arrow function - que recebe dois argumentos ( 1 ou outro /ambos)
  res.send("Boas práticas de organização!")  // quando o método for chamado retornará a msg.

});

app.listen(3000,() => { // listen método (ouvinte aguardando o localhost chamar na porta 3000 quando tem uma requisição)
  console.log("Servidor rodando na porta 3000"); /// aparece a msg no localhost 
});